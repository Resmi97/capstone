package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bank.dto.BankResponseDTO;
import com.bank.dto.CustomerResponseDTO;
import com.bank.model.Bank;
import com.bank.model.Customer_Details;
import com.bank.service.CustomerService;

@RestController
@RequestMapping(value="/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	/*--------------------------------Add Customer--------------(admin privilege)-------------*/

	@RequestMapping(value = "/addCustomer",consumes = "application/json",produces = "application/json",method = RequestMethod.POST)
	public ResponseEntity<CustomerResponseDTO>addCustomer(@RequestBody Customer_Details customer ){
		CustomerResponseDTO response=customerService.addCustomer(customer);
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
	
	/*--------------------------------View Customers-------------(admin privilege)--------------*/

	@RequestMapping(value = "/listCustomer",consumes = "application/json",produces = "application/json",method = RequestMethod.GET)
	public ResponseEntity<CustomerResponseDTO> customerList(){
		CustomerResponseDTO response=customerService.customerList();
		return new ResponseEntity<CustomerResponseDTO>(response ,HttpStatus.OK);

	}
	
	/*--------------------------------Edit Customers---------------------------*/

	@RequestMapping(value = "/updateCustomer/{accountNumber}",consumes = "application/json",produces = "application/json",method = RequestMethod.PUT)
	public ResponseEntity<CustomerResponseDTO> updateBank(@RequestBody Customer_Details customer,@PathVariable int  accountNumber){
		CustomerResponseDTO response=customerService.updateCustomer(customer, accountNumber);
		return new ResponseEntity<CustomerResponseDTO>(response ,HttpStatus.OK);

	}
	
	/*--------------------------------Delete Customers-------(admin privilege)--------------------*/
//	@RequestMapping(value = "/deleteCustomer/{accountNumber}",consumes = "application/json",produces = "application/json",method = RequestMethod.PUT)	
//	public ResponseEntity<CustomerResponseDTO> deleteCustomer(@RequestBody Customer_Details customer,@PathVariable int  accountNumber){
//		CustomerResponseDTO response=customerService.deleteCustomer(customer,accountNumber);
//		return new ResponseEntity<CustomerResponseDTO>(response ,HttpStatus.OK);
//		
//	}



}
