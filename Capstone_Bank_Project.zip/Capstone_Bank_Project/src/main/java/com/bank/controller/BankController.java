package com.bank.controller;

import javax.management.loading.PrivateClassLoader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bank.dto.BankResponseDTO;
import com.bank.model.Bank;
import com.bank.service.BankService;


@RestController
@RequestMapping(value="/admin")
public class BankController {
	
	
	@Autowired
	private BankService bankService;
	
	@RequestMapping(value = "/addBank",consumes = "application/json",produces = "application/json",method = RequestMethod.POST)
	public ResponseEntity<BankResponseDTO>addBank(@RequestBody Bank bank ){
		BankResponseDTO response=bankService.addBank(bank);
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
}
