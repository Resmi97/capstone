package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dto.BankResponseDTO;
import com.bank.model.Bank;
import com.bank.repo.BankRepo;


@Service
public class BankService {

	@Autowired
	private BankRepo repo;

	public BankResponseDTO addBank(Bank bank) {
		// TODO Auto-generated method stub
		Bank bnk=repo.save(bank);
		BankResponseDTO bnkResponseDTO=new BankResponseDTO();
		if(bnk!=null) {
			bnkResponseDTO.setStatus("SUCCESS");
			//accResponseDTO.setAccount(acc);
			bnkResponseDTO.setMsg("Bank created");
		}else {
			bnkResponseDTO.setStatus("FAIL");
			bnkResponseDTO.setStatus("not created");

			
		}
		return bnkResponseDTO;
	}
}
